function fish_prompt
        switch "$fish_key_bindings"
                case fish_hybrid_key_bindings fish_vi_key_bindings fish_helix_key_bindings
                        set STARSHIP_KEYMAP "$fish_bind_mode"
                case '*'
                        set STARSHIP_KEYMAP insert
        end
    
        set STARSHIP_CMD_PIPESTATUS $pipestatus
        set STARSHIP_CMD_STATUS $status
        # Account for changes in variable name between v2.7 and v3.0
        set STARSHIP_DURATION "$CMD_DURATION$cmd_duration"
    
        __starship_set_job_count
    
        if contains -- --final-rendering $argv; or test "$TRANSIENT" = "1"
                if test "$TRANSIENT" = "1"
                        set -g TRANSIENT 0
                        # Clear from cursor to end of screen as `commandline -f repaint` does not do this
                        # See https://github.com/fish-shell/fish-shell/issues/8418
                        printf \e\[0J
                end
                if type -q starship_transient_prompt_func
                        starship_transient_prompt_func --terminal-width="$COLUMNS" --status=$STARSHIP_CMD_STATUS --pipestatus="$STARSHIP_CMD_PIPESTATUS" --keymap=$STARSHIP_KEYMAP --cmd-duration=$STARSHIP_DURATION --jobs=$STARSHIP_JOBS
                else
                        printf "\e[1;32m❯\e[0m "
                end
        else
                /usr/bin/starship prompt --terminal-width="$COLUMNS" --status=$STARSHIP_CMD_STATUS --pipestatus="$STARSHIP_CMD_PIPESTATUS" --keymap=$STARSHIP_KEYMAP --cmd-duration=$STARSHIP_DURATION --jobs=$STARSHIP_JOBS
        end
end
